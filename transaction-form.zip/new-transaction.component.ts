import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ServiceService } from '../../../component/services/service.service';

@Component({
  selector: 'app-new-transaction',
  standalone: false,
  templateUrl: './new-transaction.component.html',
  styleUrl: './new-transaction.component.css'
})
export class NewTransactionComponent implements OnInit {

  activeTab: string = 'details'
  getDataTran: any
  transactionForm: any
  saveData: any
  saveMode: boolean = false
  editMode: boolean = true

  options = [
    {view: "delivery", value: "delivery"},
    {view: "Export", value: "export"},
    {view: "import", value: "import"}
  ]

  currancies = [
    {view: "inr", value: "inr"},
    {view: "usd", value: "usd"},
    {view: "eur", value: "eur"}
  ]

  terms = [
    {view: "net30", value: "net30"},
    {view: "net60", value: "net60"},
    {view: "cod", value: "cod"}
  ]



  constructor(private fb: FormBuilder) { }

  ngOnInit(): void {
    this.transactionForm = this.fb.group({
      transactionId: ['', Validators.required],
      transactionDate: [Date, Validators.required],
      shipmentDate: [Date, Validators.required],
      transactionType: ['', Validators.required],
      refrance: ['', Validators.required],
      customerPoNo: ['', Validators.required],
      invoiceNumber: ['', Validators.required],
      invoiceDate: [Date, Validators.required],
      invoiceDueDate: [Date, Validators.required],
      poDate: [Date, Validators.required],
      currency: ['', Validators.required],
      invoiceTerms: ['', Validators.required],
      packingReferance: ['', Validators.required],
      billOfLoding: ['', Validators.required],
      commercialInvoice: ['', Validators.required],
      airWaybill: ['', Validators.required],
      masterBol: ['', Validators.required],
      houseBol: ['', Validators.required]
    })
  }

  onSave(){
    if(this.transactionForm.valid){
      this.saveMode = !this.saveMode
      this.editMode = !this.editMode

      this.saveData = this.transactionForm.value
      console.log(this.saveData)
    }
    else{
      console.log("please fill all data")
    }
  }

  onTabSwitch(tabElement: string) {
    this.activeTab = tabElement
    console.log(this.activeTab)
  }

    getTransactionType(value: any): string {
    const selectedOption = this.options.find(opt => opt.value === value);
    return selectedOption ? selectedOption.view : '';
  }

  getCurrency(value: any): string {
    const selectedOption = this.currancies.find(opt => opt.value === value);
    return selectedOption ? selectedOption.view : '';
  }

  getInvoiceTerms(value: any): string {
    const selectedOption = this.terms.find(opt => opt.value === value);
    return selectedOption ? selectedOption.view : '';
  }
}
